Scheme
{
	Fonts
	{
		surface8
		{
			"1"
			{
				"name"		"Surface-Broesel"
				"tall"		"8"
				"additive"	"0"
				"antialias" 	"1"
				"outline"	"0"
			}
		}
		surface9
		{
			"1"
			{
				"name"		"Surface-Broesel"
				"tall"		"9"
				"additive"	"0"
				"antialias" 	"1"
				"outline"	"0"
			}
		}
		surface10
		{
			"1"
			{
				"name"		"Surface-Broesel"
				"tall"		"10"
				"additive"	"0"
				"antialias" 	"1"
				"outline"	"0"
			}
		}
		surface10shadow
		{
			"1"
			{
				"name"		"Surface-Broesel"
				"tall"		"10"
				"additive"	"0"
				"antialias" 	"1"
				"outline"	"0"
				"dropshadow"	"1"
			}
		}
		redacted8
		{
			"1"
			{
				"name"		"Redacted"
				"tall"		"8"
				"additive"	"0"
				"antialias" 	"0"
				"outline"	"0"
			}
		}
		redacted
		{
			"1"
			{
				"name"		"Squares"
				"tall"		"3" //4
				"additive"	"0"
				"antialias" 	"0"
				"outline"	"0"
			}
		}
		surface11
		{
			"1"
			{
				"name"		"Surface-Broesel"
				"tall"		"11"
				"additive"	"0"
				"antialias" 	"1"
				"outline"	"0"
			}
		}
		surface12
		{
			"1"
			{
				"name"		"Surface-Broesel"
				"tall"		"12"
				"additive"	"0"
				"antialias" 	"1"
				"outline"	"0"
			}
		}
		surface12shadow
		{
			"1"
			{
				"name"		"Surface-Broesel"
				"tall"		"12"
				"additive"	"0"
				"antialias" 	"1"
				"outline"	"0"
				"dropshadow"	"1"
			}
		}
		surface13
		{
			"1"
			{
				"name"		"Surface-Broesel"
				"tall"		"13"
				"additive"	"0"
				"antialias" 	"1"
				"outline"	"0"
			}
		}
		surface14
		{
			"1"
			{
				"name"		"Surface-Broesel"
				"tall"		"14"
				"additive"	"0"
				"antialias" 	"1"
				"outline"	"0"
			}
		}
		surface15
		{
			"1"
			{
				"name"		"Surface-Broesel"
				"tall"		"15"
				"additive"	"0"
				"antialias" 	"1"
				"outline"	"0"
			}
		}
		surface15shadow
		{
			"1"
			{
				"name"		"Surface-Broesel"
				"tall"		"15"
				"additive"	"0"
				"antialias" 	"1"
				"outline"	"0"
				"dropshadow"	"1"
			}
		}
		surface16
		{
			"1"
			{
				"name"		"Surface-Broesel"
				"tall"		"16"
				"additive"	"0"
				"antialias" 	"1"
				"outline"	"0"
			}
		}
		surface18
		{
			"1"
			{
				"name"		"Surface-Broesel"
				"tall"		"18"
				"additive"	"0"
				"antialias" 	"1"
				"outline"	"0"
			}
		}
		surface18shadow
		{
			"1"
			{
				"name"		"Surface-Broesel"
				"tall"		"18"
				"additive"	"0"
				"antialias" 	"1"
				"outline"	"0"
				"dropshadow"	"1"
			}
		}
		surface20
		{
			"1"
			{
				"name"		"Surface-Broesel"
				"tall"		"20"
				"additive"	"0"
				"antialias" 	"1"
				"outline"	"0"
			}
		}
		surface23
		{
			"1"
			{
				"name"		"Surface-Broesel"
				"tall"		"23"
				"additive"	"0"
				"antialias" 	"1"
				"outline"	"0"
			}
		}
		surface23shadow
		{
			"1"
			{
				"name"		"Surface-Broesel"
				"tall"		"23"
				"additive"	"0"
				"antialias" 	"1"
				"outline"	"0"
				"dropshadow"	"1"
			}
		}
		surface24
		{
			"1"
			{
				"name"		"SurfaceSharpened-Medium"
				"tall"		"24"
				"additive"	"0"
				"antialias" 	"1"
				"outline"	"0"
			}
		}
		surface24shadow
		{
			"1"
			{
				"name"		"SurfaceSharpened-Medium"
				"tall"		"24"
				"additive"	"0"
				"antialias" 	"1"
				"outline"	"0"
				"dropshadow"	"1"
			}
		}
		surface26
		{
			"1"
			{
				"name"		"SurfaceSharpened-Medium"
				"tall"		"26"
				"additive"	"0"
				"antialias" 	"1"
				"outline"	"0"
			}
		}
		surface26shadow
		{
			"1"
			{
				"name"		"SurfaceSharpened-Medium"
				"tall"		"26"
				"additive"	"0"
				"antialias" 	"1"
				"outline"	"0"
				"dropshadow"	"1"
			}
		}
		surface28
		{
			"1"
			{
				"name"		"SurfaceSharpened-Medium"
				"tall"		"28"
				"additive"	"0"
				"antialias" 	"1"
				"outline"	"0"
			}
		}
		surface28shadow
		{
			"1"
			{
				"name"		"SurfaceSharpened-Medium"
				"tall"		"28"
				"additive"	"0"
				"antialias" 	"1"
				"outline"	"0"
				"dropshadow"	"1"
			}
		}
		surface32
		{
			"1"
			{
				"name"		"SurfaceSharpened-Medium"
				"tall"		"32"
				"additive"	"0"
				"antialias" 	"1"
				"outline"	"0"
			}
		}
		surface36
		{
			"1"
			{
				"name"		"SurfaceSharpened-Medium"
				"tall"		"36"
				"additive"	"0"
				"antialias" 	"1"
				"outline"	"0"
			}
		}
		surface36shadow
		{
			"1"
			{
				"name"		"SurfaceSharpened-Medium"
				"tall"		"36"
				"additive"	"0"
				"antialias" 	"1"
				"outline"	"0"
				"dropshadow"	"1"
			}
		}
		surface40
		{
			"1"
			{
				"name"		"SurfaceSharpened-Medium"
				"tall"		"40"
				"additive"	"0"
				"antialias" 	"1"
				"outline"	"0"
			}
		}
		surface46
		{
			"1"
			{
				"name"		"SurfaceSharpened-Medium"
				"tall"		"52"
				"additive"	"0"
				"antialias" 	"1"
				"outline"	"0"
			}
		}
		surface56
		{
			"1"
			{
				"name"		"SurfaceSharpened-Medium"
				"tall"		"56"
				"additive"	"0"
				"antialias" 	"1"
				"outline"	"0"
			}
		}
		surfaceHPAmmo28
		{
			"1"
			{
				"name"		"SurfaceHPAmmo-Medium"
				"tall"		"28"
				"additive"	"0"
				"antialias" 	"1"
				"outline"	"0"
			}
		}
		surfaceHPAmmo56
		{
			"1"
			{
				"name"		"SurfaceHPAmmo-Medium"
				"tall"		"56"
				"additive"	"0"
				"antialias" 	"1"
				"outline"	"0"
			}
		}
		surfaceNumbers14
		{
			"1"
			{
				"name"		"SurfaceNumbers-Sharpened"
				"tall"		"14"
				"additive"	"0"
				"antialias" 	"1"
				"outline"	"0"
			}
		}
		surfaceNumbers18
		{
			"1"
			{
				"name"		"SurfaceNumbers-Sharpened"
				"tall"		"18"
				"additive"	"0"
				"antialias" 	"1"
				"outline"	"0"
			}
		}
		ItemEffectMeterLabels
		{
			"1"
			{
				"name"		"Verdana"
				"tall"		"7"
				"additive"	"0"
				"antialias" 	"1"
				"outline"	"0"
			}
		}	
		Blank
		{
			"1"
			{
				"name"		"Blank"
				"tall"		"8"
				"additive"	"0"
				"antialias" 	"1"
				"outline"	"0"
			}
		}
		"Blocks"
		{
			"1"
			{
				"name"		"Blocks"
				"tall"		"72"
				"additive"	"0"
				"antialias" "0"
			}
		}
		
		"Default"
		{
			"1"
			{
				"name"		"SurfaceSharpened-Medium"
				"tall"		"14"
				"weight"	"0"
				"antialias"	"1"
			}
			"2"
			{
				"name"		"SurfaceSharpened-Medium"
				"tall"		"15"
				"weight"	"0"
				"antialias"	"1"
			}
			"3"
			{
				"name"		"SurfaceSharpened-Medium"
				"tall"		"16"
				"weight"	"0"
				"antialias"	"1"
			}
			"4"
			{
				"name"		"SurfaceSharpened-Medium"
				"tall"		"22"
				"weight"	"0"
				"antialias"	"1"
			}
			"5"
			{
				"name"		"SurfaceSharpened-Medium"
				"tall"		"26"
				"weight"	"0"
				"antialias"	"1"
			}
			"6"
			{
				"name"		"SurfaceSharpened-Medium"
				"tall"		"14"
				"weight"	"0"
				"antialias"	"1"
			}
		}
	}
	
	CustomFontFiles
	{
		"8"
		{
			"font" "resource/fonts/Surface-Sharpened.ttf"
			"name" "SurfaceSharpened-Medium"
		}
		"9"
		{
			"font" "resource/fonts/Surface-Broesel.otf"
			"name" "Surface-Broesel"
		}
		"10"
		{
			"font" "resource/fonts/Surface-HP-and-Ammo.ttf"
			"name" "SurfaceHPAmmo-Medium"
		}
		"11"
		{
			"font" "resource/fonts/SurfaceNumbers-Sharpened.otf"
			"name" "SurfaceNumbers-Sharpened"
		}
		"12"
		{
			"font" "resource/fonts/Surface-Medium.otf"
			"name" "Surface-Medium"
		}
		"13"
		{
			"font" "resource/fonts/Blank.ttf"
			"name" "Blank"
		}
		"14"
		{
			"font" "resource/fonts/Blocks.ttf"
			"name" "Blocks"
		}
		"15"
		{
			"font" "resource/fonts/Redacted-Regular.ttf"
			"name" "Redacted8"
		}
		"16"
		{
			"font" "resource/fonts/Squares.ttf"
			"name" "Squares"
		}
	}
}