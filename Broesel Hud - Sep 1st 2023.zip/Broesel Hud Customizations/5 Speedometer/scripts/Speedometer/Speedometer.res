"Resource/HudLayout.res"
{
	"speedometer"
	{
		"visible"			"1"
		"enabled"			"1"
		"controlName"		"ImagePanel"
		"fieldName"			"speedometer"
		"zpos"				"-100"
		"xpos"				"cs-0.5"
		"ypos"				"cs+2"
		"wide"				"56" //4 wide to 1 tall
		"tall"				"14" //4 wide to 1 tall
		"image"				"replay/thumbnails/speedometerproxy"
		"scaleImage"		"1"
	}
}
